## #+TITLE: Example about stemming in Spanih 
## #+AUTHOR: Emilio Torres Manzanera
## #+DATE: Time-stamp: <2020-08-26 12:50 emilio on emilio-XPS-15-9570>
## #+TAGS: 
## #+PROPERTY: header-args :results output :exports both :session 
## https://torres.epv.uniovi.es/

## Public Domain 2020 Emilio Torres Manzanera

library(data.table)
library(fastmatch)
source("lematizador.R")

head(spmorphemes) # You can modify this list. See http://www.datsi.fi.upm.es/~coes/
head(spdictionary) # You can modify this data.frame with your own words!
head(spcommonwords) # You can modify this data.frame with your own words!

system.time(lematizador("grandullón")) # First time it takes a lot of time (see ?fmatch)
system.time(lematizador("grandullón"))

lematizador( "des" ) # dar
lematizador( "anduve" ) # andar
lematizador( "casitas" ) ## NA : Try  http://www.datanalytics.com/blog/2011/12/13/un-lematizador-para-el-espanol-con-r-¿cutre-¿mejorable/
                         ## Or modify the spdictionary!
lematizador( "comimos" ) # comer
lematizador( "queremos") # querer
lematizador( "patatas" ) # patata


